<?php
return [
    'host' => 'localhost',
    'username' => 'root',
    'password' => '',
    'database' => 'e-mutasi',
];
