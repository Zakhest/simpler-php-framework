<?php

class Mutasi extends Controller {
    public function index()  {
        $this->loadView('mutasi');
    }
}