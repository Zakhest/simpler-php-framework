<?php

class UserModel extends Model {
    public function __construct() {
        parent::__construct('login');
    }
}
